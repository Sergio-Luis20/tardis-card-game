package br.sergio.tcg;

import lombok.experimental.StandardException;

@StandardException
public class GameLogicException extends RuntimeException {
}
