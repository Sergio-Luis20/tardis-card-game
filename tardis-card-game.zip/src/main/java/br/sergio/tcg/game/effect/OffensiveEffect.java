package br.sergio.tcg.game.effect;

import br.sergio.tcg.game.AttributeSource;

public interface OffensiveEffect extends StatusEffect, AttributeSource {
}
