package br.sergio.tcg.game.card;

import lombok.experimental.StandardException;

@StandardException
public class NotACardClassException extends RuntimeException {
}
