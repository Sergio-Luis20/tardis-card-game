package br.sergio.tcg.game.card.family;

public interface FoodCard extends CardFamily {
}
