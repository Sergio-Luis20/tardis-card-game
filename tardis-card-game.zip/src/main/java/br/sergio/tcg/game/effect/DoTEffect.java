package br.sergio.tcg.game.effect;

public interface DoTEffect extends OffensiveEffect {
}
