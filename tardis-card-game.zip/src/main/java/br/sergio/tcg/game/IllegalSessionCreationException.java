package br.sergio.tcg.game;

public class IllegalSessionCreationException extends Exception {
    public IllegalSessionCreationException(String message) {
        super(message);
    }
}
