package br.sergio.tcg.game;

public interface AttributeSource {

    AttributeInstance getAttribute();

}
