package br.sergio.tcg.game.battle;

public enum DamageType {

    NORMAL,
    TRUE,
    DOT,
    REFLECT,
    CUSTOM;

}
