package br.sergio.tcg.game;

public class SessionStartException extends RuntimeException {
    public SessionStartException(String message) {
        super(message);
    }
}
