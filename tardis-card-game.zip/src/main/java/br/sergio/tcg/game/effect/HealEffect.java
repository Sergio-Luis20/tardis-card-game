package br.sergio.tcg.game.effect;

import br.sergio.tcg.game.AttributeSource;

public interface HealEffect extends StatusEffect, AttributeSource {
}
