package br.sergio.tcg.game.card.family;

public interface CardFamily {
}
