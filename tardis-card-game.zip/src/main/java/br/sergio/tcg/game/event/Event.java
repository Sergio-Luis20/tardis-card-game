package br.sergio.tcg.game.event;

public interface Event {
}
